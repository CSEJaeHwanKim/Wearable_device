enyo.kind({

	// ...........................
	// PUBLIC PROPERTIES

	// ...........................
	// PROTECTED PROPERTIES

	// ...........................
	// COMPUTED PROPERTIES

	// ...........................
	// PUBLIC METHODS

	// ...........................
	// PROTECTED METHODS

	// ...........................
	// OBSERVERS

});