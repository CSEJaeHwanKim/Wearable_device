enyo.depends(
	'enyo.js',
	'version.js',
	'ready.js',
	'rendered.js',
	'../../loader.js',
	'boot.js'
);
