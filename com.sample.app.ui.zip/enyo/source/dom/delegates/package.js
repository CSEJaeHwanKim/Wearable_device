enyo.depends(
	'HTMLStringDelegate.js'
);