enyo.depends(
	'DocumentFragmentDelegate.js'
);